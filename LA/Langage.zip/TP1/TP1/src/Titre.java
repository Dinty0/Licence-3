public class Titre {

	private String titre;
	
	public Titre(String titre){
		this.titre=titre;
	}
	
	public String getTitre(){
		return this.titre;
	}
}
