abstract class Decorator extends Boisson
{
  protected Boisson boisson;

  // "Constructeur" (même si Decorator est abstract)
  // servant juste à ses classes decendantes 
  // à initialiser PRIX
  protected Decorator( double prix )
  {
    super( prix );
  }

  @Override
  public abstract double cout();

  @Override
  public abstract String getDescription();
}