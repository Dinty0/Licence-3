import java.io.*;
import java.awt.event.*;

class ButtonChocolat implements ActionListener
{
  private SwingBucks sb_;

  public ButtonChocolat(SwingBucks sb)
  {
    sb_ = sb;
  }

  public void actionPerformed( ActionEvent event )
  {
    if( sb_.asBoisson() )
      {
	sb_.setBoisson( new Chocolat( sb_.getBoisson(), "Chocolat" ) );
	System.out.println( sb_.getBoisson().getDescription() );
      }
    else
      System.out.println( "Erreur : choississez une boisson d'abord." );
  }
}