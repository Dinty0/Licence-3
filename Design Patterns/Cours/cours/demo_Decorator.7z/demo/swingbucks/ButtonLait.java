import java.io.*;
import java.awt.event.*;

class ButtonLait implements ActionListener
{
  private SwingBucks sb_;

  public ButtonLait(SwingBucks sb)
  {
    sb_ = sb;
  }

  public void actionPerformed( ActionEvent event )
  {
    if( sb_.asBoisson() )
      {
	sb_.setBoisson( new Lait( sb_.getBoisson(), "Lait" ) );
	System.out.println( sb_.getBoisson().getDescription() );
      }
    else
      System.out.println( "Erreur : choississez une boisson d'abord." );
  }
}