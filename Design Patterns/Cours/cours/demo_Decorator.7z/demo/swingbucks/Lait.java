class Lait extends Decorator
{
  public Lait( Boisson boisson, String description )
  {
    super( 0.25 );
    this.boisson = boisson;
    this.description = description;
  }

  @Override
  public double cout()
  {
    return boisson.cout() + PRIX;
  }

  @Override
  public String getDescription()
  {
    return boisson.getDescription() + " " + description;
  }
}