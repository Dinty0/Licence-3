import javax.swing.*;
import java.awt.*;

class SwingBucks
{
  private Boisson boisson;

  public void setBoisson( Boisson boisson )
  {
    this.boisson = boisson;
  }

  public Boisson getBoisson()
  {
    return boisson;
  }

  public boolean asBoisson()
  {
    return boisson != null;
  }

  public void prepareFrame()
  {
    JFrame	frame		= new JFrame	("SwingBucks");

    JButton	espresso	= new JButton	( "Espresso" );
    JButton	colombia	= new JButton	( "Colombia" );
    JButton	moka		= new JButton	( "Moka" );
    JButton	deca		= new JButton	( "Deca" );

    JButton	lait		= new JButton	( "Lait" );
    JButton	caramel		= new JButton	( "Caramel" );
    JButton	chocolat	= new JButton	( "Chocolat" );
    JButton	chantilly	= new JButton	( "Chantilly" );

    JButton	total		= new JButton	( "Total" );
    JButton	raz		= new JButton	( "RAZ" );

    JPanel	mainPanel	= new JPanel	( new GridLayout( 0, 4, 10, 10 ));

    frame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );

    espresso.addActionListener( new Espresso( this, "Espresso" ) );
    colombia.addActionListener( new Colombia( this, "Colombia" ) );
    moka.addActionListener( new Moka( this, "Moka" ) );
    deca.addActionListener( new Deca( this, "Deca" ) );

    mainPanel.add( espresso );
    mainPanel.add( colombia );
    mainPanel.add( moka );
    mainPanel.add( deca );

    lait.addActionListener( new ButtonLait( this ) );
    caramel.addActionListener( new ButtonCaramel( this ) );
    chocolat.addActionListener( new ButtonChocolat( this ) );
    chantilly.addActionListener( new ButtonChantilly( this ) );

    mainPanel.add( lait );
    mainPanel.add( caramel );
    mainPanel.add( chocolat );
    mainPanel.add( chantilly );

    total.addActionListener( new Total( this ) );
    raz.addActionListener( new RAZ( this ) );

    mainPanel.add( total );
    mainPanel.add( raz );

    frame.setContentPane( mainPanel );
    frame.setMinimumSize(new Dimension(620,150));
    frame.pack();
    frame.setVisible(true);
  }

  public static void main(String [] args)
  {
    SwingBucks action = new SwingBucks();
    action.prepareFrame();
  }
}
