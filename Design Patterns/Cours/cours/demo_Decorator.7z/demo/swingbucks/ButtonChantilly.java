import java.io.*;
import java.awt.event.*;

class ButtonChantilly implements ActionListener
{
  private SwingBucks sb_;

  public ButtonChantilly(SwingBucks sb)
  {
    sb_ = sb;
  }

  public void actionPerformed( ActionEvent event )
  {
    if( sb_.asBoisson() )
      {
	sb_.setBoisson( new Chantilly( sb_.getBoisson(), "Chantilly" ) );
	System.out.println( sb_.getBoisson().getDescription() );
      }
    else
      System.out.println( "Erreur : choississez une boisson d'abord." );
  }
}