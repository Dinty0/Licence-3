class Chantilly extends Decorator
{
  public Chantilly( Boisson boisson, String description )
  {
    super( 0.30 );
    this.boisson = boisson;
    this.description = description;
  }

  @Override
  public double cout()
  {
    return boisson.cout() + PRIX;
  }

  @Override
  public String getDescription()
  {
    return boisson.getDescription() + " " + description;
  }
}