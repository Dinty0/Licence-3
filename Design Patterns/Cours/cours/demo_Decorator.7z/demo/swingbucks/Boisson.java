abstract class Boisson
{
  protected String description;
  protected final double PRIX;

  // "Constructeur" (même si Boisson est abstract)
  // servant juste à ses classes decendantes 
  // à initialiser PRIX
  protected Boisson( double prix )
  {
    PRIX = prix;
  }

  public double cout()
  {
    return PRIX;
  }
  
  public String getDescription()
  {
    return description;
  }
}