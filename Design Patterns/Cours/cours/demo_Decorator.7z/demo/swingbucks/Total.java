import java.io.*;
import java.awt.event.*;

class Total implements ActionListener
{
  private SwingBucks sb_;
  
  public Total( SwingBucks sb )
  {
    sb_ = sb;
  }

  public void actionPerformed( ActionEvent event )
  {
    if( sb_.asBoisson() )
      System.out.println( sb_.getBoisson().cout() );
    else
      System.out.println( "Erreur : choississez une boisson d'abord." );
  }
}