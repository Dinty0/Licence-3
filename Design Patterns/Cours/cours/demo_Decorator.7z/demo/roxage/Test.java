import java.io.*;

class Test
{
  public static void main(String [] args)
  {
    int c;
    try
      {
	InputStream in = new FileInputStream( "roxage.txt" );
	in = new BufferedInputStream( in ); // décoration
	in = new LowerCaseInputStream( in ); // décoration

	while( (c = in.read()) >= 0 )
	  {
	    System.out.print( (char)c );
	  }
      }
    catch( IOException e)
      {
	e.printStackTrace();
      }
  }
}