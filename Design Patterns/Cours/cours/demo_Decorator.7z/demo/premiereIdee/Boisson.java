abstract class Boisson
{
  protected boolean lait;
  protected boolean caramel;
  protected boolean chocolat;
  protected boolean chantilly;

  abstract public double cout();
  abstract public double getPrixBase();
  
  public boolean hasLait() { return lait; }
  public void setLait( boolean lait ) {this.lait = lait; }

  public boolean hasCaramel() { return caramel; }
  public void setCaramel( boolean caramel ) { this.caramel = caramel; }

  public boolean hasChocolat() { return chocolat; }
  public void setChocolat( boolean chocolat ) { this.chocolat = chocolat; }

  public boolean hasChantilly() { return chantilly; }
  public void setChantilly( boolean chantilly ) { this.chantilly = chantilly; }
}