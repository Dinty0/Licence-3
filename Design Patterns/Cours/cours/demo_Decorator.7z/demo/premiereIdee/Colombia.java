import java.io.*;

class Colombia extends Boisson
{
  private final double PRIXBASE;

  public Colombia()
  {
    PRIXBASE = 1.2;
    lait = false;
    caramel = false;
    chocolat = false;
    chantilly = false;
  }

  @Override
  public double cout()
  {
    return PRIXBASE +
      (lait ? 0.25 : 0) +
      (caramel ? 0.40 : 0) +
      (chocolat ? 0.40 : 0) +
      (chantilly ? 0.30 : 0);
  }

  @Override
  public double getPrixBase() { return PRIXBASE; } 

  public static void main(String [] args)
  {
    Colombia colombia = new Colombia();
    colombia.setLait( true );
    colombia.setCaramel( true );

    System.out.println( "Prix = " + colombia.cout() );
  }
}