import javax.swing.*;
import java.awt.event.*;
import java.io.*;

class Action1 implements ActionListener
{
  public void actionPerformed( ActionEvent event )
  {
    System.out.println( "Action 1" );
  }
}
