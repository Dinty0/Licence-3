import javax.swing.*;
import java.awt.*;

class ActionBouton
{
  JFrame frame;

  public void prepareFrame()
  {
    frame = new JFrame();
    frame.setSize(350, 50);
    frame.setLocation(100, 100);
    frame.show();
  }

  public void cEstParti()
  {
    JButton bouton = new JButton( "Prêt pour de l'action ?" );
    bouton.addActionListener( new Action1() );
    bouton.addActionListener( new Action2() );
    frame.getContentPane().add( BorderLayout.CENTER, bouton );    
  }

  public static void main(String [] args)
  {
    ActionBouton action = new ActionBouton();
    action.prepareFrame();

    action.cEstParti();
  }
}
