import javax.swing.*;
import java.awt.event.*;
import java.io.*;

class Action2 implements ActionListener
{
  public void actionPerformed( ActionEvent event )
  {
    System.out.println( "Action 2" );
  }
}
