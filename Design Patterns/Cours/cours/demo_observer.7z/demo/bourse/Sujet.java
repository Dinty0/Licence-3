interface Sujet
{
  void addObs(Observer o);
  void deleteObs(Observer o);
  void notifyObs();
}