import javax.swing.*;
import javax.swing.text.*;
import java.text.*;
import java.awt.GridLayout;

public class AffichageCours implements Observer {
  private JFrame frame = null;
  private JPanel contentPane = null;
  private JScrollPane scrollCours = null;

  private Panneau textCac40 = new Panneau("CAC 40");
  private Panneau textNasdaq = new Panneau("Nasdaq");
  private Panneau textNikkei = new Panneau("Nikkei 225");

  private Panneau valueCac40;
  private Panneau valueNasdaq;
  private Panneau valueNikkei;
	
  private NumberFormat format = null;
  
  private double cac40_;
  private double nasdaq_;
  private double nikkei_;

  private Sujet db_;

  public AffichageCours(Sujet db) {
    db_ = db;
    db_.addObs( this );

    buildFrame(cac40_, nasdaq_, nikkei_);
  }
	
  private void buildFrame(double cac40, double nasdaq, double nikkei) {
    frame = new JFrame();
    
    contentPane = new JPanel( new GridLayout( 2, 1 ) );
    
    valueCac40 =  new Panneau( cac40 );
    valueNasdaq =  new Panneau( nasdaq );
    valueNikkei =  new Panneau( nikkei );

    textCac40.setHorizontalAlignment(JLabel.LEFT);
    textCac40.setVerticalAlignment(JLabel.TOP);

    textNasdaq.setHorizontalAlignment(JLabel.CENTER);
    textNasdaq.setVerticalAlignment(JLabel.TOP);

    textNikkei.setHorizontalAlignment(JLabel.RIGHT);
    textNikkei.setVerticalAlignment(JLabel.TOP);

    valueCac40.setHorizontalAlignment(JLabel.LEFT);
    valueCac40.setVerticalAlignment(JLabel.BOTTOM);

    valueNasdaq.setHorizontalAlignment(JLabel.CENTER);
    valueNasdaq.setVerticalAlignment(JLabel.BOTTOM);

    valueNikkei.setHorizontalAlignment(JLabel.RIGHT);
    valueNikkei.setVerticalAlignment(JLabel.BOTTOM);

    contentPane.add(textCac40);
    contentPane.add(textNasdaq);
    contentPane.add(textNikkei);

    contentPane.add(valueCac40);
    contentPane.add(valueNasdaq);
    contentPane.add(valueNikkei);

    frame.setLocationRelativeTo(null);               
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    frame.setSize(250, 60);
    frame.setContentPane(contentPane);
    frame.setTitle("Cours actuels");
    frame.pack();
  }

  public void close() {
    frame.dispose();
  }
  
  public void display() {
    frame.setVisible(true);
  }
  
  public void update(double cac40, double nasdaq, double nikkei)
 {
    if( cac40_ != cac40 )
      {
	cac40_ = cac40;
	valueCac40.setValue( cac40_ );
      }
    
    if( nasdaq_ != nasdaq )
      {
	nasdaq_ = nasdaq;
	valueNasdaq.setValue( nasdaq_ );
      }
    
    if( nikkei_ != nikkei )
      {
	nikkei_ = nikkei;
	valueNikkei.setValue( nikkei_ );
      }
  }
}