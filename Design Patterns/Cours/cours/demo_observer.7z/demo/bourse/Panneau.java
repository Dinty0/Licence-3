import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.lang.*;

class Panneau extends JLabel
{
  private String value_;

  public Panneau(String value)
  {
    super(value);
    value_ = value;
    setFont(new Font("Serif", Font.PLAIN, 21));
  }

  public Panneau(double value)
  {
    this( Double.toString( value ) );
  }

  public void setValue(String value)
  {
    value_ = value;
    setText(value_);
    blink();
  }    

  public void setValue(double value)
  {
    setValue( Double.toString( value ) );
  }

  public void blink()
  {
    setFont(new Font("Serif", Font.BOLD, 21));
    // on reste 0.5s comme ca
    try{ Thread.sleep(500); }
    catch( InterruptedException ex ) { Thread.currentThread().interrupt(); }

    setFont(new Font("Serif", Font.PLAIN, 21));
    // on reste 0.5s comme ca
    try{ Thread.sleep(500); }
    catch( InterruptedException ex ) { Thread.currentThread().interrupt(); }

    setFont(new Font("Serif", Font.BOLD, 21));
    // on reste 0.5s comme ca
    try{ Thread.sleep(500); }
    catch( InterruptedException ex ) { Thread.currentThread().interrupt(); }

    setFont(new Font("Serif", Font.PLAIN, 21));
  }
}