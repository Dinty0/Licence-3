import java.util.*;
import java.net.*;
import java.io.*;
import java.lang.*;

class Bourse
{
  public static void main( String [] args ) throws Exception 
  {
    String path = "http://finance.yahoo.com/d/quotes.csv?s=%5EFCHI+%5EIXIC+%5EN225&f=l1";
    URL url = new URL( path );
    DonneesBourse data = new DonneesBourse( url );
    AffichageCours aff = new AffichageCours( data );
    
    aff.display();
    while( true )
      {
	Thread.sleep(1000);
	data.setData();
      }
  }
}
