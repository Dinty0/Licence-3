interface Observer
{
  public void update(double cac40, double nasdaq, double nikkei);
}