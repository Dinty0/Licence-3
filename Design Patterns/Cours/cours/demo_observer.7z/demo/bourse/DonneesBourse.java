import java.util.*;
import java.net.*;
import java.io.*;

class DonneesBourse implements Sujet
{
  private double cac40_;
  private double nasdaq_;
  private double nikkei_;
  
  private URL url_;

  private ArrayList<Observer> observers;

  public DonneesBourse(URL url)
  {
    url_ = url;
    observers = new ArrayList<Observer>();
    try
      {
	setData();
      }
    catch(Exception e)
      {
	e.printStackTrace();
      } 
  }
  
  public void setData() throws Exception 
  {
    BufferedReader in = new BufferedReader(new InputStreamReader(url_.openStream()));
    ArrayList<String> inputLine = new ArrayList<String>();
    String tmp;
    while( ( tmp = in.readLine() ) != null )
      {
	inputLine.add( tmp );
      }
    in.close();

    cac40_ = Double.parseDouble( inputLine.get(0) );
    nasdaq_ = Double.parseDouble( inputLine.get(1) );
    nikkei_ = Double.parseDouble( inputLine.get(2) );

    notifyObs();
  }

  public void addObs(Observer o)
  {
    observers.add(o);
  }

  public void deleteObs(Observer o)
  {
    observers.remove(o);
  }

  public void notifyObs()
  {
    for( int i = 0; i < observers.size(); ++i )
      observers.get(i).update(cac40_, nasdaq_, nikkei_);
  }
}
